# Targets

Faction: **Blood Angels**
Surface: **Lenses & Gems**

## Studio / Official Reference Links
- https://www.warhammer.com/en-GB/shop/warhammer-40000/space-marines/blood-angels
- https://www.warhammer-community.com/en-gb/articles/dc86aytp/starting-a-blood-angels-army-in-warhammer-40000-everything-you-need-to-know-from-painting-to-lore/
- https://www.warhammer-community.com/en-gb/articles/6qpc8cnl/grotmas-calendar-day-3-loyalist-legion-painting-guide/

## Notes
- Final standard v1: faction-specific official anchors.
- Upgrade later: add a single, surface-specific box-art/product page image link per surface (v2 truth pass).
