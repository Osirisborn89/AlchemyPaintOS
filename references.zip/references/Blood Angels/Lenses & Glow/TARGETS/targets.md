# Targets

Faction: **Blood Angels**
Surface: **Lenses & Glow**

## Studio / Official Reference Links
- https://www.warhammer.com/en-GB/
- https://warhammer40000.com/the-armies/

## Notes
- Final standard v1: faction-specific official anchors.
- Upgrade later (Truth Pass v2): add a surface-specific box-art/studio reference link and tune steps to match using owned paints.
