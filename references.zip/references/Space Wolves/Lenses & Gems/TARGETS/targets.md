# Targets

Faction: **Space Wolves**
Surface: **Lenses & Gems**

## Studio / Official Reference Links
- https://www.warhammer.com/en-GB/shop/warhammer-40000/space-marines/space-wolves
- https://warhammer40000.com/the-armies/

## Notes
- Final standard v1: faction-specific official anchors.
- Upgrade later: add a single, surface-specific box-art/product page image link per surface (v2 truth pass).
