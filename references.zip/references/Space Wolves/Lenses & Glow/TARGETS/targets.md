# TARGETS — Space Wolves — Lenses & Glow

Truth Pass v2 anchor links for this surface. (Updated: 20260107_012929)

## Official / curated references
- https://www.youtube.com/watch?v=0I79IGIYKqM
- https://thearmypainter.com/en-gb/blogs/explore/the-army-painter-academy-how-to-paint-space-wolves

## Notes
- Target: classic Space Wolves feel: red lenses + cold blue plasma/glow.
- Recipe intent: neat red lens with bright highlight + white reflection dot; blue glow with a white hotspot.

