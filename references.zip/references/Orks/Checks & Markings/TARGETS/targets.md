# TARGETS — Orks — Checks & Markings

Truth Pass v2 anchor links for this surface. (Updated: 20260106_211136)

## Official / curated references
- https://www.warhammer-community.com/2021/08/02/warhammer-40000-how-to-paint-your-kill-team-octarius-kommandos/
- https://www.facebook.com/warhammer40000uk/posts/lots-of-you-have-asked-to-see-how-we-would-paint-ork-boyz-super-fast-to-get-them/2151713231815971/
- https://www.warhammer.com/en-JP/shop/warhammer-40000/xenos-armies/orks

## Notes
- Default direction: classic Orks (green skin, dark armour/plates, high-contrast checks where relevant, worn steel).
- If you later want a specific clan (Goffs/Evil Sunz/Bad Moons/Deathskulls), we’ll fork variant surfaces.

