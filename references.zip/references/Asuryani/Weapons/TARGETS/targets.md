# Targets

Faction: **Asuryani**
Surface: **Weapons**

## Studio / Official Reference Links
- https://www.warhammer.com/en-GB/shop/warhammer-40000/xenos-armies/aeldari
- https://warhammer40000.com/the-armies/

## Notes
- Asuryani = Craftworld Aeldari (classic Eldar).
- Final standard v1: faction-specific official anchors.
- Upgrade later: add a single, surface-specific box-art/product page image link per surface (v2 truth pass).

