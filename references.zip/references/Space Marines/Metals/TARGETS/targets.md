# TARGETS — Space Marines — Metals

Truth Pass v2 anchor links for this surface. (Updated: 20260107_011049)

## Official / curated references
- https://www.warhammer.com/en-WW/shop/warhammer-40000-introductory-set-2023-eng
- https://www.warhammer-community.com/en-gb/articles/mo9yNrni/must-watch-the-armouring-of-a-space-marine/
- https://www.goonhammer.com/how-to-paint-everything-ultramarines/
- https://www.youtube.com/watch?v=FSl3pN9oY8k

## Notes
- Default = codex-compliant blue armour (generic Space Marines).
- If you want a specific chapter, we will set a chapter-specific scheme later and keep this bucket as 'Generic/Unassigned'.

