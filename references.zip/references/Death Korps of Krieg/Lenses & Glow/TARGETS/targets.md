# Targets

Faction: **Death Korps of Krieg**
Surface: **Lenses & Glow**

## Reference Links (official + curated)
- https://www.warhammer-community.com/en-gb/articles/starting-an-astra-militarum-army-in-warhammer-40000-everything-you-need-to-know-from-painting-to-lore/
- https://www.goonhammer.com/how-to-paint-everything-veteran-guardsmen-death-korps-of-krieg/
- https://taleofpainters.com/2021/08/tutorial_how_to_paint_death_korps_of_krieg/
- https://paintpad.app/recipes/10278-death-korps-of-krieg-eavy-metal

## Notes
- Krieg has multiple accepted schemes; this project uses curated/box-art-style references as compass.
- Translate into owned paints only (inventory_export.csv).
- No NMM during Truth Pass v2.

