# Targets

Faction: **Drukhari**
Surface: **Bases**

## Reference Links (official + curated)
- https://www.warhammer-community.com/en-gb/articles/fiqetk3h/starting-a-drukhari-army-in-warhammer-40000-everything-you-need-to-know-from-painting-to-lore/
- https://www.warhammer-community.com/en-gb/articles/bgbwxdst/witness-the-evolution-of-a-collection-with-one-hobbyists-two-drukhari-armies/
- https://www.goonhammer.com/how-to-paint-everything-drukhari/
- https://taleofpainters.com/2016/07/tutorial-how-to-paint-dark-eldar/
- https://paintpad.app/recipes/3752-kabal-of-the-black-heart-kabalite-warrior
- https://www.youtube.com/watch?v=zlrBbyO8tAA

## Notes
- Compass scheme: **dark/black armour with teal-blue edge highlights**, red gems/lenses, cold metals.
- Translate using owned paints only (inventory_export.csv).
- No NMM in Truth Pass v2.

