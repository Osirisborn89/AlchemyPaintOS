# TARGETS — White Scars — Leather

Truth Pass v2 anchor links for this surface. (Updated: 20260107_150659)

## Official / curated references
- https://www.warhammer-community.com/en-gb/2019/08/28/white-scars-rules-and-ways-to-use-themgw-homepage-post-1/
- https://taleofpainters.com/2020/02/tutorial-how-to-paint-white-armor-using/
- https://www.youtube.com/watch?v=W9NGcO9Bc00

## Notes
- Default scheme: clean white armour, red markings, dark weapons, neutral metals.
- Paint picks MUST come from inventory_export.csv; this runbook selects closest matches and prints what it chose.

