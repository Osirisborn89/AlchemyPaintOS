# TARGETS — T'au Empire — Bases

Truth Pass v2 anchor links for this surface. (Updated: 20260107_114849)

## Official / curated references
- https://thearmypainter.com/en-gb/blogs/explore/painting-the-tau-hobbying-for-the-greater-good
- https://www.warhammer-community.com/tag/tau-empire/
- https://www.warhammer-community.com/en-gb/articles/uWIYhQ7Q/tau-empire-meet-the-new-auxiliaries/
- https://www.warhammer.com/en-GB/shop/Tau-Empire-Fire-Warriors-2017

## Notes
- Default scheme: T'au Sept-style ochre/tan armour + white sept markings + dark weapons.
- Paint picks MUST come from inventory_export.csv.

