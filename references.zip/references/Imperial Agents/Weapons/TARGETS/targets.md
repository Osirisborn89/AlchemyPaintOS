# TARGETS — Imperial Agents — Weapons

Truth Pass v2 anchor links for this surface. (Updated: 20260107_124326)

## Official / curated references
- https://www.warhammer-community.com/en-gb/articles/z7umaNJP/imperial-agents-detachments-enlist-rogue-traders-into-inquisitorial-operations/
- https://www.warhammer-community.com/en-gb/articles/2I9ivMFF/sunday-preview-rising-from-the-ashes-of-faith/
- https://www.warhammer-community.com/en-gb/articles/hlDHFb6h/kill-team-ashes-of-faith-gives-you-a-horde-of-zealots-and-inquisitorial-agents-in-one-box/
- https://www.warhammer.com/en-GB/

## Notes
- Imperial Agents are a mixed roster; this project uses a consistent 'studio-style Inquisition/Agents' vibe per links above.
- Step paints must remain inventory-valid (non-Generic paints must exist in inventory_export.csv).

