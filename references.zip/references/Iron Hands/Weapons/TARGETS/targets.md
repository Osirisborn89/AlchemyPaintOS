# TARGETS — Iron Hands — Weapons

Truth Pass v2 anchor links for this surface. (Updated: 20260106_201723)

## Official / curated references
- https://taleofpainters.com/2013/09/tutorial-how-to-paint-iron-hands-space/
- https://www.goonhammer.com/how-to-paint-space-marines-iron-hands/
- https://www.youtube.com/results?search_query=Warhammer+Iron+Hands+painting+tutorial
- https://www.youtube.com/results?search_query=Iron+Hands+Space+Marines+painting+guide

## Notes
- Aim: classic Iron Hands (black armour, steel bionics, red lenses; clean and industrial).
- Keep armour highlights subtle (dark grey -> mid grey). Metals can be brighter.

