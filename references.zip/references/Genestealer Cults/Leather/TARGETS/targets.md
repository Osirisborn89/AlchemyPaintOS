# Targets

Faction: **Genestealer Cults**
Surface: **Leather**

## Reference Links (official + curated)
- https://www.warhammer-community.com/en-gb/articles/WdP1REPb/starting-a-genestealer-cults-army-in-warhammer-40000-everything-you-need-to-know-from-painting-to-lore/
- https://www.warhammer-community.com/en-gb/articles/hYoeO0W4/the-gangs-and-genestealers-of-hive-secundus-painted-by-the-warhammer-studio/
- https://www.goonhammer.com/how-to-paint-everything-genestealer-cults/
- https://www.youtube.com/watch?v=WqgL3J5fGM8

## Notes
- Compass scheme: **industrial greys + purple cult cloth/accents**, pale alien skin, worn steel.
- Translate using owned paints only (inventory_export.csv).
- No NMM in Truth Pass v2.

