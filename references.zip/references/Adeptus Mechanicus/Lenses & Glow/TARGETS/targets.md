# Targets

Faction: **Adeptus Mechanicus**
Surface: **Lenses & Glow**
Scheme compass: **Mars Red (official/box-art compass)**

## Official / Box Art / Studio Reference Anchors
- https://warhammer40000.com/the-armies/
- https://www.warhammer.com/en-GB/shop/warhammer-40000/armies-of-the-imperium/adeptus-mechanicus
- https://www.warhammer.com/en-GB/shop/Combat-Patrol-Adeptus-Mechanicus-2021

## Notes
- Truth Pass v2: rewrite steps to match the compass using **owned paints only**.
- Generic allowed only when needed; prefer a specific owned paint when available.
