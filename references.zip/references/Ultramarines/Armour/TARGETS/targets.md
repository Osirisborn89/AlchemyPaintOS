# TARGETS — Ultramarines — Armour

Truth Pass v2 anchor links for this surface. (Updated: 20260107_145013)

## Official / curated references
- https://www.warhammer-community.com/
- https://www.warhammer.com/en-GB/home
- https://citadelcolour.com/
- https://www.goonhammer.com/how-to-paint-everything-ultramarines/

## Notes
- Default scheme: classic Ultramarines (blue armour, gold trim, red lenses).
- Paint picks MUST come from inventory_export.csv; this runbook selects closest matches and prints what it chose.

