# TARGETS — Thousand Sons — Weapons

Truth Pass v2 anchor links for this surface. (Updated: 20260107_120729)

## Official / curated references
- https://www.warhammer-community.com/en-gb/articles/HRQIYdNz/gallery-a-stunning-thousand-sons-army-from-richard-gray/
- https://thearmypainter.com/blogs/explore/the-army-painter-academy-how-to-paint-thousand-sons
- https://www.youtube.com/watch?v=pIqHATHsll0

## Notes
- Default scheme for this rewrite: classic Thousand Sons teal armour + gold trim, red cloth, dark weapons, eerie green glow.
- Paint picks MUST come from inventory_export.csv; this runbook selects closest matches and prints what it chose.

