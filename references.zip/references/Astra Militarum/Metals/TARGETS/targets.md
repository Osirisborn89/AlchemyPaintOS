# Targets

Faction: **Astra Militarum**
Surface: **Metals**

## Studio / Official Reference Links
- https://www.warhammer.com/en-GB/shop/astra-militarum-cadian-shock-troops-2023
- https://taleofpainters.com/2022/11/tutorial-how-to-paint-the-new-cadian-shock-troops-effectively/

## Notes
- Compass: Cadian Shock Troops / Cadian Command Squad product photography + curated painting breakdowns.
- Intent: match the official/box-art read using ONLY owned paints (inventory_export.csv).
- No NMM in Truth Pass v2.

