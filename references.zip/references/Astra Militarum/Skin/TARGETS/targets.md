# Targets

Faction: **Astra Militarum**
Surface: **Skin**

## Studio / Official Reference Links
- https://www.warhammer.com/en-GB/shop/astra-militarum-cadian-shock-troops-2023
- https://cadianshock.com/painting-imperial-guard-infantry/

## Notes
- Compass: Cadian Shock Troops / Cadian Command Squad product photography + curated painting breakdowns.
- Intent: match the official/box-art read using ONLY owned paints (inventory_export.csv).
- No NMM in Truth Pass v2.

