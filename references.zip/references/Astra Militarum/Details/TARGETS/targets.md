# Targets

Faction: **Astra Militarum**
Surface: **Details**

## Studio / Official Reference Links
- https://www.warhammer.com/en-GB/shop/astra-militarum-cadian-command-squad-2023
- https://citadelcolour.com/videos/how-to-paint-cadian-regimental-standard/
- https://www.warhammer.com/en-GB/shop/astra-militarum-cadian-shock-troops-2023

## Notes
- Compass: Cadian Shock Troops / Cadian Command Squad product photography + curated painting breakdowns.
- Intent: match the official/box-art read using ONLY owned paints (inventory_export.csv).
- No NMM in Truth Pass v2.

