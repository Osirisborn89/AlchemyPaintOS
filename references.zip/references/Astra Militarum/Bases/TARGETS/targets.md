# Targets

Faction: **Astra Militarum**
Surface: **Bases**

## Studio / Official Reference Links
- https://citadelcolour.com/videos/battlefield-mud/
- https://www.warhammer.com/en-GB/shop/astra-militarum-cadian-shock-troops-2023

## Notes
- Compass: Cadian Shock Troops / Cadian Command Squad product photography + curated painting breakdowns.
- Intent: match the official/box-art read using ONLY owned paints (inventory_export.csv).
- No NMM in Truth Pass v2.

