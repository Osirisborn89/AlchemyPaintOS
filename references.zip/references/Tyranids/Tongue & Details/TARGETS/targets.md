# TARGETS — Tyranids — Tongue & Details

Truth Pass v2 anchor links for this surface. (Updated: 20260107_142041)

## Official / curated references
- https://www.warhammer-community.com/2024/05/10/get-your-leviathan-tyranids-battle-ready-with-this-quick-and-easy-painting-guide/
- https://www.warhammer-community.com/2023/06/20/batch-paint-your-favourite-tyranids-with-these-simple-contrast-recipes/
- https://www.youtube.com/watch?v=hLHy-EgGC58

## Notes
- Default scheme for this rewrite: Hive Fleet Leviathan studio/box-art vibe (bone skin + purple/black carapace).
- Paint picks MUST come from inventory_export.csv (closest matches).

