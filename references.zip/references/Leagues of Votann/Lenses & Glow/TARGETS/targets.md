# TARGETS — Leagues of Votann — Lenses & Glow

Truth Pass v2 anchor links for this surface. (Updated: 20260106_202435)

## Official / curated references
- https://www.warhammer-community.com/en-gb/articles/FSTwgg9k/youve-met-the-big-five-leagues-of-votann-but-how-do-they-play/
- https://www.warhammer-community.com/en-gb/articles/g1yEw3G7/how-the-warhammer-community-painters-brought-the-leagues-of-votann-to-life/
- https://www.youtube.com/watch?v=-J3llT5zWnA

## Notes
- Default scheme target: Greater Thurian League (turquoise/green-blue + cream), orange lenses, dark undersuit, silver/brass metals.
- This is a dashboard-friendly 'default'. Variants (Ymyr red, Trans-Hyperian orange, etc.) can be added later as separate recipe sets.

