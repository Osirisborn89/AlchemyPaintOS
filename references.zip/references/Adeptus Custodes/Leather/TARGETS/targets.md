# Targets

Faction: **Adeptus Custodes**
Surface: **Leather**
Scheme compass: **Classic Gold (official/box-art compass)**

## Official / Box Art / Studio References
- https://www.warhammer.com/en-GB/shop/warhammer-40000/armies-of-the-imperium/adeptus-custodes
- https://www.warhammer.com/en-GB/shop/Adeptus-Custodes-Custodian-Guard-2018
- https://www.warhammer.com/en-GB/shop/combat-patrol-adeptus-custodes-2024
- https://www.warhammer-community.com/en-gb/articles/LRraZYf4/starting-an-adeptus-custodes-army-in-warhammer-40000-everything-you-need-to-know-from-painting-to-lore/
- https://www.warhammer-community.com/en-gb/articles/jFoLOANO/golden-gods-one-warhammer-community-staffers-incredible-adeptus-custodes-army/

## Notes
- Truth Pass v2: rewrite steps to match the compass using **owned paints only**.
- Generic allowed only when needed; prefer a specific owned paint when available.
