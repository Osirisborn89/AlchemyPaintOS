# TARGETS — Raven Guard — Leather

Truth Pass v2 anchor links for this surface. (Updated: 20260106_215538)

## Official / curated references
- https://www.warhammer-community.com/tag/raven-guard/
- https://www.warhammer-community.com/2021/12/03/grotmas-calendar-day-3-loyalist-legion-painting-guide/
- https://www.warhammer.com/en-WW/shop/the-horus-heresy/loyalist-legiones-astartes/raven-guard

## Notes
- Aim: classic Raven Guard — black armour, cool grey edge highlights, white iconography, red lenses.
- Keep highlights subtle; Raven Guard reads best when it stays *black*, not grey.

