# Targets

Faction: **Deathwatch**
Surface: **Weapons**

## Reference Links (official + curated)
- https://www.warhammer-community.com/en-gb/videos/iqweaxch/getting-better-at-painting-black-armour/
- https://www.goonhammer.com/how-to-paint-everything-deathwatch/
- https://www.warhammerdigital.com/all-products/htp-deathwatch.html
- https://www.warhammer-community.com/en-gb/articles/vftonolg/kill-team-communicatus-the-warhammer-community-team-paint-the-deathwatch/

## Notes
- Compass: black armour with crisp edge highlights + silver (Deathwatch) arm/metal.
- Translate using owned paints only (inventory_export.csv).
- No NMM in Truth Pass v2.

