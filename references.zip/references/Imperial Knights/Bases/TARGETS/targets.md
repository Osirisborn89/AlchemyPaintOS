# TARGETS — Imperial Knights — Bases

Truth Pass v2 anchor links for this surface. (Updated: 20260106_195518)

## Official / curated references
- https://www.warhammer.com/en-GB/shop/warhammer-40000/armies-of-the-imperium/imperial-knights
- https://www.warhammer-community.com/en-gb/
- https://www.goonhammer.com/start-competing-imperial-knights-tactics/

## Notes
- Aim: classic studio Imperial Knights: clean armour panels, strong metallics, hazard stripes optional.
- House colours vary massively; this recipe set uses a neutral, dashboard-friendly baseline you can later branch.

