# TARGETS — Necrons — Lenses & Glow

Truth Pass v2 anchor links for this surface. (Updated: 20260106_203912)

## Official / curated references
- https://www.warhammer-community.com/en-gb/articles/52nnJxjf/dynastic-colours/
- https://www.warhammer-community.com/en-gb/articles/0dpotpp5/video-how-to-paint-necron-armour/
- https://www.goonhammer.com/how-to-paint-everything-necrons/

## Notes
- Aim: classic Necrons — metallic bodies with dark recess shading and bright green energy glow.
- Dynasty colours vary; this pass sets a safe, classic baseline.

