# TARGETS — Ynnari — Armour

Truth Pass v2 anchor links for this surface. (Updated: 20260107_155708)

## Official / curated references
- https://www.warhammer-community.com/en-gb/articles/7pbncskx/starting-an-aeldari-army-everything-you-need-to-know-to-begin-collecting-and-painting/
- https://www.youtube.com/watch?v=dk6Gl1z36E8

## Notes
- Default for this rewrite: Ynnari studio vibe (bone/ivory armour + deep red cloth + dark weapons + elegant metals + bright spiritstones).
- Paint picks MUST come from inventory_export.csv; this runbook prints what it chose.

