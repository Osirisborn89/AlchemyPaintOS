# Targets

Faction: **Death Guard**
Surface: **Flesh**

## Studio / Official Reference Links
- https://www.warhammer.com/en-GB/shop/Death-Guard-Plague-Marines-2020
- https://www.warhammer-community.com/en-gb/articles/xixjivoy/starting-a-death-guard-army-in-warhammer-40000-everything-you-need-to-know-from-painting-to-lore/
- https://www.goonhammer.com/how-to-paint-death-guard-thechirurgeons-method/
- https://taleofpainters.com/2018/09/tutorial-death-guard-plague-marines/

## Notes
- Compass: 40K Death Guard (Plague Marines) box-art vibe: sickly green armour, brass/bronze trim, grime.
- Translate into owned paints only (inventory_export.csv).
- No NMM in Truth Pass v2.

