# Targets

Faction: **Emperor's Children**
Surface: **Lenses & Glow**

## Reference Links (official + curated)
- https://www.warhammer-community.com/en-gb/articles/hsqlxqbs/starting-an-emperors-children-army-in-warhammer-40000-everything-you-need-to-know-from-painting-to-lore/
- https://www.goonhammer.com/how-to-paint-everything-emperors-children-chaos-space-marines/
- https://www.youtube.com/watch?v=AJYOF6WcujQ

## Notes
- Compass scheme: **purple/pink armour accents + gold trim**, loud but clean.
- Translate using owned paints only (inventory_export.csv).
- No NMM in Truth Pass v2.

