# Targets

Faction: **Grey Knights**
Surface: **Lenses & Glow**

## Reference Links (curated)
- https://www.goonhammer.com/how-to-paint-everything-grey-knights/
- https://thearmypainter.com/en-gb/blogs/explore/the-army-painter-academy-grey-knights
- https://www.youtube.com/watch?v=9Legp2128ag

## Notes
- Compass: Grey Knights = blue-steel armour, red/white heraldry accents, psychic blue glows.
- This surface covers: helmet lenses + small glow/OSL accents.
- Truth Pass v2 rules: inventory-only paints, keep it simple, no NMM.

