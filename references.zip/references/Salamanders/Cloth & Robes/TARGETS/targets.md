# TARGETS — Salamanders — Cloth & Robes

Truth Pass v2 anchor links for this surface. (Updated: 20260107_004842)

## Official / curated references
- https://www.warhammer-community.com/en-gb/topics/painting/
- https://warhammer40k.fandom.com/wiki/Salamanders
- https://www.nobleknight.com/P/2147755901/Space-Marines-Salamanders-Primaris-Upgrades-and-Transfers

## Notes
- Aim: classic Salamanders (rich green armour, black weapons/trim accents, red lenses, silver metals).
- If you want a specific 3rd/4th/5th company shoulder trim later, we can add it as an optional variant.

