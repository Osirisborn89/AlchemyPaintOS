# Targets

Faction: **Aeldari - Purple**
Surface: **Details**

## Studio / Official Reference Links
- https://www.warhammer.com/en-GB/shop/warhammer-40000/xenos-armies/aeldari
- https://warhammer40000.com/the-armies/

## Notes
- Variant: Purple scheme (keep consistent across this faction folder).
- Final standard v1: faction-specific official anchors.
- Upgrade later: add a single, surface-specific box-art/product page image link per surface (v2 truth pass).
