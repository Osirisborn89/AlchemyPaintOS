# TARGETS — Imperial Fists — Leather

Truth Pass v2 anchor links for this surface. (Updated: 20260106_194049)

## Official / curated references
- https://www.warhammer-community.com/en-gb/articles/oFV9eOQ1/space-marines-showcase-darcys-imperial-fists/
- https://www.youtube.com/watch?v=raFZphUA8uk
- https://www.warhammer.com/en-GB/shop/Imperial-Fists-Primaris-Upgrades-2020
- https://www.goonhammer.com/fists-of-fury-part-1-imperial-fists/

## Notes
- Aim: classic Imperial Fists (yellow armour, black details/casings, red lenses, silver metals).
- Company trim varies (black/red/white/green). Default recipe uses black trim.

